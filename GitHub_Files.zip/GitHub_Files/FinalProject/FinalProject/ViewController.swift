//
//  ViewController.swift
//  FinalProject
//
//  Created by ROY on 12/12/24.
//

import UIKit


class ViewController: UIViewController {
    
    
    @IBOutlet var button1: UIButton!
    @IBOutlet var button2: UIButton!
    @IBOutlet var img1: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func button1Click() {
        
    }
    
}
