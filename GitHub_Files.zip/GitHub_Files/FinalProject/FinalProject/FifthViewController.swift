//
//  FifthViewController.swift
//  FinalProject
//
//  Created by ROY on 12/12/24.
//

import UIKit
import CoreLocation

class FifthViewController: UIViewController {
    
    
    @IBOutlet var tf1: UITextField!
    
    @IBOutlet var button6: UIButton!
    @IBOutlet var label3: UILabel!
    @IBOutlet var label4: UILabel!
    @IBOutlet var label5: UILabel!
    @IBOutlet var label6: UILabel!
    @IBOutlet var label7: UILabel!
    @IBOutlet var label8: UILabel!
    @IBOutlet var label9: UILabel!
    
    @IBOutlet var button7: UIButton!
    
    let locationManager = CLLocationManager()
        
        var lat: String!
        var long: String!
        var tempvalue: String!
        var admini: String!
        var local: String!
        var windSpeed: String!
        var address : String!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
       
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


