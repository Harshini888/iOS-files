//
//  SecondViewController.swift
//  FinalProject
//
//  Created by ROY on 12/12/24.
//

import UIKit


class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet var tv1: UITableView!
    
    @IBOutlet var label1: UILabel!
    @IBOutlet var label2: UILabel!
    
    
    @IBOutlet var img2: UIImageView!
    
    @IBOutlet var button3: UIButton!

    
    
    
    var FlightName: [String] = []
    var FlightUrl: [String] = []
    var FlightImage: [String] = []
    var TrainName: [String] = []
    var TrainUrl: [String] = []
    var TrainImage: [String] = []
    var BusName: [String] = []
    var BusUrl: [String] = []
    var BusImage: [String] = []
    var CabName: [String] = []
    var CabUrl: [String] = []
    var CabImage: [String] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        tv1.delegate = self
        tv1.dataSource = self
        
        FlightName = ["goibibo", "makemytrip", "yatra", "cleartrip"]
        
        FlightUrl =
        ["https://www.goibibo.com/", "https://www.makemytrip.com/", "https://www.yatra.com/", "https://www.cleartrip.com/"]
        FlightImage = ["img1.jpeg", "img4.jpeg", "img12.jpeg", "img7.jpeg"]
        
        
        TrainName = ["trainman", "makemytrip", "ixigo", "irctc"]
        TrainUrl = ["https://www.trainman.com/", "https://www.makemytrip.com/", "https://www.ixigo.com/", "https://www.irctc.co.in/"]
        TrainImage = ["img6.jpeg", "img4.jpeg", "img2.jpeg", "img3.jpeg"]
        
        
        BusName = ["goibibo", "abhi bus", "makemytrip", "red bus"]
        BusUrl = ["https://www.goibibo.com/", "https://www.abhibus.com/", "https://www.makemytrip.com/", "https://www.redbus.com/" ]
        BusImage = ["img1.jpeg", "img8.jpeg", "img4.jpeg", "img5.jpeg"]
        
        CabName = ["uber", "rapido", "bolt"]
        CabUrl = ["https://www.uber.com/","https://www.rapido.com/","https://www.bolt.in/"]
        CabImage = ["img9.jpeg", "img10.jpeg", "img11.jpeg"]
        
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                
                if section == 0{
                    return FlightName.count
                }
                else if section == 1{
                    return TrainName.count
                }
                else if section == 2{
                    return BusName.count
                }
                else {
                    return CabName.count
                }
            }
            //3.create & display the info in cells
            func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                
                if indexPath.section == 0 {
                    let cell1 = tableView.dequeueReusableCell(withIdentifier: "ID1", for: indexPath)
                    
                    cell1.textLabel?.text = FlightName[indexPath.row]
                    cell1.accessoryType = .detailDisclosureButton
                    return cell1
                    
                }
                else if indexPath.section == 1{
                    let cell2 = tableView.dequeueReusableCell(withIdentifier: "ID1", for: indexPath)
                    cell2.textLabel?.text = TrainName[indexPath.row]
                    cell2.accessoryType = .detailDisclosureButton
                    return cell2
                }
                else if indexPath.section == 2{
                    let cell3 = tableView.dequeueReusableCell(withIdentifier: "ID1", for: indexPath)
                    cell3.textLabel?.text = BusName[indexPath.row]
                    cell3.accessoryType = .detailDisclosureButton
                    return cell3
                }
                else {
                    let cell4 = tableView.dequeueReusableCell(withIdentifier: "ID1", for: indexPath)
                    cell4.textLabel?.text = CabName[indexPath.row]
                    cell4.accessoryType = .detailDisclosureButton
                    return cell4
                    
                    
                }
            }
            
            // 4. header title
            func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
                if section == 0{
                    return "Flights"
                }
                else if section == 1{
                    return "Trains"
                }
                else if section == 2{
                    return "Buss"
                }
                else {
                    return "Cabs"
                }
            }
            
            //5. Footer title
            func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
                if section == 0 {
                    return "Flights Ends"
                }
                else if section == 1 {
                    return "Trains Ends"
                }
                else if section == 2 {
                    return "Bus Ends"
                }
                else {
                    return "Cabs Ends"
                }
                
            }
            //6. when user select any row in tableview
            
            func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
                if indexPath.section == 0{
                    label1.text = FlightName[indexPath.row]
                    label2.text = FlightUrl[indexPath.row]
                    img2.image = UIImage(named: FlightImage[indexPath.row])
                }
                else if indexPath.section == 1{
                    label1.text = TrainName[indexPath.row]
                    label2.text = TrainUrl[indexPath.row]
                    img2.image = UIImage(named: TrainImage[indexPath.row])
                }
                else if indexPath.section == 2{
                    label1.text = BusName[indexPath.row]
                    label2.text = BusUrl[indexPath.row]
                    img2.image = UIImage(named: BusImage[indexPath.row])
                }
                else {
                    
                    label1.text = CabName[indexPath.row]
                    label2.text = CabUrl[indexPath.row]
                    img2.image = UIImage(named: CabImage[indexPath.row])
                }
            }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


