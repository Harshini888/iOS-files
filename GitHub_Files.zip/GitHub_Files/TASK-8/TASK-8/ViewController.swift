//
//  ViewController.swift
//  TASK-8
//
//  Created by ROY on 02/12/24.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    
    @IBOutlet var add:UIButton!
    @IBOutlet var share: UIButton!
    @IBOutlet var anyTxt: UITextField!
    @IBOutlet var url: UITextField!
    @IBOutlet var img: UIImageView!

    var PhotoLibraryImagePicker1: UIImagePickerController!
    var cameraImagePicker2: UIImagePickerController!
    
        var buttonLayer : CALayer!
        var textfieldLayer : CALayer!
        var imageviewLayer : CALayer!
        var screenviewLayer : CALayer!


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        textfieldLayer = anyTxt.layer
                textfieldLayer.cornerRadius = 15
                textfieldLayer.borderColor = UIColor.brown.cgColor
                textfieldLayer.borderWidth = 3
                
                textfieldLayer.backgroundColor = UIColor.green.cgColor
        
        
        imageviewLayer = img.layer
                imageviewLayer.cornerRadius = 11
                imageviewLayer.borderColor = UIColor.black.cgColor
                imageviewLayer.borderWidth = 3
                
                imageviewLayer.backgroundColor = UIColor.yellow.cgColor
        
        
        screenviewLayer = self.view.layer
                screenviewLayer.borderColor = UIColor.orange.cgColor
                screenviewLayer.borderWidth = 20
                screenviewLayer.cornerRadius = 60
        
        
        buttonLayer = add.layer
                buttonLayer.cornerRadius = 12
                buttonLayer.borderColor = UIColor.cyan.cgColor
                buttonLayer.borderWidth = 2
                
                textfieldLayer.backgroundColor = UIColor.black.cgColor
        
        buttonLayer = share.layer
                buttonLayer.cornerRadius = 14
                buttonLayer.borderColor = UIColor.gray.cgColor
                buttonLayer.borderWidth = 5
                
                textfieldLayer.backgroundColor = UIColor.white.cgColor
        
    }
    
    
    
    
    @IBAction func displayAddBtn(){
        let alert = UIAlertController(title: "Select Photo Option", message: "Please Select Any Option", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Photo Library", style: .default, handler:{ (_) in
            print("Photo library Button Clicked")
            
            //var PhotoLibraryImagePicker1: UIImagePickerController!
            
            self.PhotoLibraryImagePicker1 = UIImagePickerController()
            self.PhotoLibraryImagePicker1.sourceType = .photoLibrary
            self.PhotoLibraryImagePicker1.delegate = self
            self.PhotoLibraryImagePicker1.allowsEditing = false
            
            self.present(self.PhotoLibraryImagePicker1, animated: true)
            
        }))
       
        
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler:{ (_) in
            print("camera Button Clicked")
            
            if(UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
            {
                self.cameraImagePicker2 = UIImagePickerController()
                self.cameraImagePicker2.delegate = self
                self.cameraImagePicker2.sourceType = .camera
                self.cameraImagePicker2.cameraDevice = .rear
                self.cameraImagePicker2.allowsEditing = true
                
                self.present(self.cameraImagePicker2, animated: true)
                
            }
            
            else {
                
                print("camera not found in Simulator")
                
            }
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler:{ (_) in
            print("Dismiss Button clicked")
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if picker == PhotoLibraryImagePicker1 {
            
            print("selected Image Details: \(info)")
            
            let image1 = info [.originalImage] as! UIImage
            
            img.image = image1
            
            self.dismiss(animated: true, completion: nil)
            
            
        }
        
    }
    
    @IBAction func displayShare(){
        
        
        let text = anyTxt.text
        let image = img.image
        let myWebsite = URL(string: url.text!)
        
        let shareAll = [text as Any, image as Any, myWebsite!] as [Any]
        
        print(shareAll)
        
        let activityViewController = UIActivityViewController(activityItems: shareAll, applicationActivities: nil)
        
        activityViewController.popoverPresentationController?.sourceView = self.view
           
        self.present(activityViewController, animated: true)
    }


}











    
  
    
    
    
    
