//
//  ViewController.swift
//  Assessment-2(Q1)
//
//  Created by ROY on 28/11/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var tf1: UITextField!
    @IBOutlet var tf2: UITextField!
    @IBOutlet var b1: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
        
    @IBAction func displayClickHere() {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let nextScreen = segue.destination as! SecondViewController
        
        nextScreen.url1 = tf2.text
        nextScreen.titles = tf1.text
    }
            
        }
        


    
