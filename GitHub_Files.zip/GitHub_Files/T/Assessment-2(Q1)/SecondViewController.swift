//
//  SecondViewController.swift
//  Assessment-2(Q1)
//
//  Created by ROY on 28/11/24.
//

import UIKit
import WebKit

class SecondViewController: UIViewController {
    
    @IBOutlet var wv1: WKWebView!
    
    var url1: String!
    var titles: String!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        var url = URL(string: url1)
        var req1 = URLRequest(url: url!)
        self.wv1.load(req1)
        self.navigationItem.title = titles
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
