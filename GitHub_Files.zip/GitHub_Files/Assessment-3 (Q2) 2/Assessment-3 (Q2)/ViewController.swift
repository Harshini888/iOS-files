//
//  ViewController.swift
//  Assessment-3 (Q2)
//
//  Created by ROY on 08/12/24.
//
import UIKit
import CoreLocation

class ViewController: UIViewController {
    
    @IBOutlet var tf1: UITextField!
    
    @IBOutlet var info: UIButton!
    @IBOutlet var showMaps: UIButton!
    
    @IBOutlet var lat: UILabel!
    @IBOutlet var lon: UILabel!
    @IBOutlet var temperature: UILabel!
    @IBOutlet var humidity: UILabel!
    @IBOutlet var windspeed: UILabel!
    @IBOutlet var address: UILabel!
    @IBOutlet var descript: UILabel!
    
    let locationManager = CLLocationManager()
    var latitude: String!
    var longitude: String!
    var temperaturevalue: String!
    var administrativeArea: String!
    var locality: String!
    var windSpeed: String!
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func infoClick() {
        
        let session1 = URLSession.shared
        
        let webserviceURL = URL(string: "http://api.openweathermap.org/data/2.5/weather?q=\(tf1.text!)&APPID=f31356634fbc4c64c86edd02aaf817c2&units=metric")!
        
        print("Sending Request --> Webservice URL:\n\(webserviceURL)")
        
        
        
        let task1 = session1.dataTask(with: webserviceURL) {
            (data: Data?, response: URLResponse?, error: Error?) in
            if let error1 = error
            {
                print("Error:\n\(error1)")
            }
            else
            {
                if let data1 = data
                {
                    
                    print("Bytes Data:\n\(data1)")
                    
                    
                    let dataString = String(data: data1, encoding: String.Encoding.utf8)
                    
                    print("All the weather data:\n\(dataString!)")
                    
                    
                    
                    if let firstDictionary = try? JSONSerialization.jsonObject(with: data1, options: .allowFragments) as? NSDictionary
                    {
                        
                        print("first Dictionary values: \(firstDictionary)")
                        
                        if let secondDictionary = firstDictionary.value(forKey: "main") as? NSDictionary {
                            
                            print("main Dictionary values are: \(secondDictionary)")
                            
                            
                            // to display windspeed
                            if let windDictionary = firstDictionary.value(forKey: "wind") as? NSDictionary {
                                print("wind Dictionary values are: \(windDictionary)")
                                if let windspeedvalue = windDictionary.value(forKey: "speed") {
                                    DispatchQueue.main.sync {
                                        print("\(self.tf1.text!): \(windspeedvalue)")
                                        self.windspeed.text = " WindSpeed: \(windspeedvalue)"
                                    }
                                }
                            }
                            if let weatherArray = firstDictionary.value(forKey: "weather") as? NSArray,
                               let firstWeather = weatherArray.firstObject as? NSDictionary,
                               let descriptValue = firstWeather.value(forKey: "description") as? String {
                                DispatchQueue.main.async {
                                    self.descript.text = "Description: \(descriptValue)"
                                }
                            }
                            
                                if let temperaturevalue = secondDictionary.value(forKey: "temp") {
                                    DispatchQueue.main.async {
                                        print("\(self.tf1.text!): \(temperaturevalue)°C")
                                        self.temperature.text = "\(self.tf1.text!) Temperature: \(temperaturevalue)°C"
                                    }
                                }
                                
                                if let humidityValue = secondDictionary.value(forKey: "humidity") {
                                    DispatchQueue.main.async {
                                        print("\(self.tf1.text!): \(humidityValue)°C")
                                        self.humidity.text = "Humidity: \(humidityValue)"
                                    }
                                }
                                if let thirdDictionary = firstDictionary.value(forKey: "coord") as? NSDictionary {
                                    
                                    if let latValue = thirdDictionary.value(forKey: "lat") {
                                        DispatchQueue.main.async {
                                            self.lat.text = "Latitude: \(latValue)"
                                            self.latitude = "\(latValue)"
                                        }
                                    }
                                    
                                    
                                    if let longValue = thirdDictionary.value(forKey: "lon") {
                                        DispatchQueue.main.async {
                                            self.lon.text = "Longitude: \(longValue)"
                                            self.longitude = "\(longValue)"
                                            
                                        }
                                    }
                                    
                                    if let latitude = thirdDictionary.value(forKey: "lat") as? Double,
                                       let longitude = thirdDictionary.value(forKey: "lon") as? Double {
                                        let location = CLLocation(latitude: latitude, longitude: longitude)
                                        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
                                            if error != nil {
                                                let alert = UIAlertController(title: "Geocoding error", message: "Invalid Details.", preferredStyle: .alert)
                                                alert.addAction(UIAlertAction(title: "OK", style: .default))
                                                self.present(alert, animated: true)
                                                return
                                            } else if let placemark = placemarks?.first {
                                                DispatchQueue.main.async {
                                                    
                                                    let name = placemark.name ?? "Unknown"
                                                    let country = placemark.country ?? "Unknown"
                                                    let administrativeArea = placemark.administrativeArea ?? "Unknown"
                                                    let locality = placemark.locality ?? "Unknown"
                                                    let postalCode = placemark.postalCode ?? "Unknown"
                                                    
                                                    self.administrativeArea = "\(administrativeArea)"
                                                    self.locality = "\(locality)"
                                                    self.address.text = """
                                                           \(name)
                                                           \(country)
                                                           \(administrativeArea)
                                                           \(locality)
                                                           \(postalCode)
                                                           """
                                                    
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                        }
                    }
                }
            }
            
            
            task1.resume()
            
        }
        
        @IBAction func showMapsClick() {
            
        }
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            
            let nextScreen = segue.destination as! SecondViewController
            
            nextScreen.title = tf1.text
            nextScreen.lat = latitude
            nextScreen.long = longitude
            nextScreen.temp = temperaturevalue
            nextScreen.admin = administrativeArea
            nextScreen.loc = locality
            
           
        }
    }


