//
//  SecondViewController.swift
//  Assessment-3 (Q2)
//
//  Created by ROY on 08/12/24.
//

import UIKit
import MapKit
import QuartzCore

class SecondViewController: UIViewController {

    @IBOutlet weak var map1: MKMapView!
    @IBOutlet weak var sc1: UISegmentedControl!
    
    
    var lat: String!
    var long: String!
    var temp: String!
    var admin: String!
    var loc: String!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let staticLocation = CLLocationCoordinate2D(latitude: Double(lat ?? "") ?? 0.0, longitude: Double(long ?? "") ?? 0.0)
        
        
        let span1 = MKCoordinateSpan(latitudeDelta: 0.003, longitudeDelta: 0.003)
        
        let region1 = MKCoordinateRegion(center: staticLocation, span: span1)
        
        map1.setRegion(region1, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = staticLocation
        annotation.title = "Address: \(admin!), \(loc!)"
        map1.addAnnotation(annotation)
        
    }
    
    @IBAction func sc1Click() {
        
        if sc1.selectedSegmentIndex == 0
        {
            map1.mapType = .standard
        }  else if sc1.selectedSegmentIndex == 1 {
            map1.mapType = .satellite
        } else {
            map1.mapType = .hybrid
        }
    }
}



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


