//
//  ViewController.swift
//  ASSMENT2
//
//  Created by FCI on 28/11/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

