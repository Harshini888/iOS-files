//
//  ViewController.swift
//  ImageViewandPageControlApp
//
//  Created by shamitha on 24/11/24.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate{
    
    
    @IBOutlet var iv : UIImageView!
    @IBOutlet var pc : UIPageControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func displlayImagess(){
        
        let index:Int = pc.currentPage
        
        if index == 0{
            iv.image = UIImage(named: "img1")
            self.view.backgroundColor = .purple
        }
        
        else if index == 1{
            iv.image = UIImage(named: "img2")
            self.view.backgroundColor = .blue
        }
        else if index == 2{
            iv.image = UIImage(named: "img3")
            self.view.backgroundColor = .gray
        }
        else if index == 3{
            iv.image = UIImage(named: "img4")
            self.view.backgroundColor = .brown
        }
        else{
            iv.image = UIImage(named: "img5")
            self.view.backgroundColor = .yellow
            
            
        }
        
        
        
        
    }
}
