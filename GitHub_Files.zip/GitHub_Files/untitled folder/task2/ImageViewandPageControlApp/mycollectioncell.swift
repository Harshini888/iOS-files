//
//  mycollectioncell.swift
//  ImageViewandPageControlApp
//
//  Created by shamitha on 24/11/24.
//

import UIKit

class mycollectioncell: UICollectionViewController {
    
    @IBOutlet var iv : UIImageView!
    @IBOutlet var pc: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }


}
