//
//  ViewController.swift
//  ActivityIndicatorandImage
//
//  Created by shamitha on 24/11/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var ac: UIActivityIndicatorView!
    @IBOutlet var img: UIImageView!
    
    var timer : Timer!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        ac.startAnimating()
        img.isHidden = true
        timer = Timer.scheduledTimer(timeInterval:10.0 , target: self, selector: #selector(stopAnimation), userInfo: nil, repeats: false)
    }
    
    @objc func stopAnimation(){
        
        ac.stopAnimating()
        ac.hidesWhenStopped = true
        self.img.isHidden = false
        self.img.image = UIImage(named: "img1")
        self.view.backgroundColor = .black

        
    }
    
    

        }
        
    
         
        




