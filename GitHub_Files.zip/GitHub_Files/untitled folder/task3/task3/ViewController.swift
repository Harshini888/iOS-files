//
//  ViewController.swift
//  task3
//
//  Created by shamitha on 25/11/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var sc1: UISegmentedControl!
    @IBOutlet var label1 : UILabel!
    @IBOutlet var iv1 : UIImageView!
    @IBOutlet var tv1 : UITextView!
    
    var sc2: UISegmentedControl!
    var label2 : UILabel!
    var iv2 : UIImageView!
    var tv2 : UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    @IBAction func sc1Click(){
        let index = sc1.selectedSegmentIndex
        
        if index == 0{
            label1.text = "Charminar"
            iv1.image = UIImage(named: "img1")
            tv1.text = "charminar"
            do{
                let path = Bundle.main.path(forResource: "charminar", ofType: "txt")
                
                let str = try String(contentsOfFile: path!)
                tv1.text = str
            }
            catch{
                print(error.localizedDescription)
            }
        }
        if index == 1{
            label1.text = "Red Fort"
            iv1.image = UIImage(named: "img2")
            tv1.text = "red fort"
            do{
                let path = Bundle.main.path(forResource: "red fort", ofType: "txt")
                
                let str = try String(contentsOfFile: path!)
                tv1.text = str
            }
            catch{
                print(error.localizedDescription)
            }
        }
        if index == 2{
            label1.text = "Taj Mahal"
            iv1.image = UIImage(named: "img3")
            tv1.text = "taj mahal"
            do{
                let path = Bundle.main.path(forResource: "taj mahal", ofType: "txt")
                
                let str = try String(contentsOfFile: path!)
                tv1.text = str
            }
            catch{
                print(error.localizedDescription)
            }
        }
        
        
            
        }
    }
    

